--
-- PostgreSQL database dump
--

\restrict zGyStZQjuGkcmP95u5non3QYTx8RxDpUho30cioHJjwHszXT8aMBDUcgtgqPN0h

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: todo_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO todo_user;

--
-- Name: todos; Type: TABLE; Schema: public; Owner: todo_user
--

CREATE TABLE public.todos (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    done boolean NOT NULL
);


ALTER TABLE public.todos OWNER TO todo_user;

--
-- Name: todos_id_seq; Type: SEQUENCE; Schema: public; Owner: todo_user
--

CREATE SEQUENCE public.todos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.todos_id_seq OWNER TO todo_user;

--
-- Name: todos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: todo_user
--

ALTER SEQUENCE public.todos_id_seq OWNED BY public.todos.id;


--
-- Name: todos id; Type: DEFAULT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.todos ALTER COLUMN id SET DEFAULT nextval('public.todos_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: todo_user
--

COPY public.alembic_version (version_num) FROM stdin;
0001_create_todos
\.


--
-- Data for Name: todos; Type: TABLE DATA; Schema: public; Owner: todo_user
--

COPY public.todos (id, title, done) FROM stdin;
2	Learn PostgreSQL persistence	f
1	Learn CRUD update	t
\.


--
-- Name: todos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: todo_user
--

SELECT pg_catalog.setval('public.todos_id_seq', 8, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: todos todos_pkey; Type: CONSTRAINT; Schema: public; Owner: todo_user
--

ALTER TABLE ONLY public.todos
    ADD CONSTRAINT todos_pkey PRIMARY KEY (id);


--
-- Name: ix_todos_id; Type: INDEX; Schema: public; Owner: todo_user
--

CREATE INDEX ix_todos_id ON public.todos USING btree (id);


--
-- PostgreSQL database dump complete
--

\unrestrict zGyStZQjuGkcmP95u5non3QYTx8RxDpUho30cioHJjwHszXT8aMBDUcgtgqPN0h

